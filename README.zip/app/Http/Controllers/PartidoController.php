<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class PartidoController extends Controller
{
    public function verParticipantes(){
        $participantes = User::where('status_user',1)->get();
        $paises = ['Guatemala','El Salvador','Honduras','Nicaragua','Costa Rica'];

        foreach ($participantes as $participante) {
            $participante->pais = $paises[--$participante->pais_id];
        }

        return view('modulos.participantes',['participantes' => $participantes]);
    }
}
