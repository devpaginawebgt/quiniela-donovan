<?php

namespace App\Http\Controllers;

use App\Models\Equipo;
use App\Models\Partido;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EquipoController extends Controller
{
    public function verModuloGrupos(){
        $this->actualizarPuntosEquipos();
        return view('modulos.grupos');
    }

    public function equiposGrupo($grupo_get){
        $grupo = strtoupper($grupo_get);

        $equipos = Equipo::where('grupo',$grupo)->orderBy('puntos','desc')->get();
        return json_encode($equipos);
    }

    public function partidosGrupo(Request $grupoJornada){
        $grupo = strtoupper($grupoJornada->grupo);
        $consulta1 = "SELECT * FROM `equipo_partidos` 
        INNER JOIN equipos on equipo_partidos.equipo_1 = equipos.id 
        or equipo_partidos.equipo_2 = equipos.id
        INNER JOIN partidos on equipo_partidos.partido_id = partidos.id
        where equipos.grupo='$grupo' and (partidos.jornada=$grupoJornada->jornada)";

        $partidosGrupo = DB::select(DB::raw($consulta1));

        return json_encode($partidosGrupo);
    }

    public function partidosJornada($jornada){
        $consulta1 = "SELECT * FROM `equipo_partidos` 
        INNER JOIN equipos on equipo_partidos.equipo_1 = equipos.id 
        or equipo_partidos.equipo_2 = equipos.id
        INNER JOIN partidos on equipo_partidos.partido_id = partidos.id
        where (partidos.jornada=$jornada)";

        $partidosJornada = DB::select(DB::raw($consulta1));

        return json_encode($partidosJornada);
    }

    public function actualizarPuntosEquipos(){

        $resultados = DB::select("SELECT goles_equipo_1,goles_equipo_2,resultado_partidos.partido_id,equipo_1,equipo_2 
                FROM `resultado_partidos` 
                INNER JOIN partidos on resultado_partidos.partido_id = partidos.id 
                INNER JOIN equipo_partidos on partidos.id = equipo_partidos.partido_id 
                WHERE partidos.estado=0");
    
        foreach ($resultados as $resultado) {
            if($resultado->goles_equipo_1 > $resultado->goles_equipo_2){

                $equipoGanador = Equipo::find($resultado->equipo_1);
                $equipoGanador->goles_favor += $resultado->goles_equipo_1;
                $equipoGanador->goles_contra += $resultado->goles_equipo_2;
                $equipoGanador->partidos_jugados += 1;
                $equipoGanador->partidos_ganados += 1;
                $equipoGanador->puntos += 3;
                $equipoGanador->save();

                $equipoPerdedor = Equipo::find($resultado->equipo_2);
                $equipoPerdedor->goles_favor += $resultado->goles_equipo_2;
                $equipoPerdedor->goles_contra += $resultado->goles_equipo_1;
                $equipoPerdedor->partidos_jugados += 1;
                $equipoPerdedor->partidos_perdidos += 1;
                $equipoPerdedor->save();
            }elseif ($resultado->goles_equipo_1 < $resultado->goles_equipo_2) {

                $equipoGanador = Equipo::find($resultado->equipo_2);
                $equipoGanador->goles_favor += $resultado->goles_equipo_2;
                $equipoGanador->goles_contra += $resultado->goles_equipo_1;
                $equipoGanador->partidos_jugados += 1;
                $equipoGanador->partidos_ganados += 1;
                $equipoGanador->puntos += 3;
                $equipoGanador->save();

                $equipoPerdedor = Equipo::find($resultado->equipo_1);
                $equipoPerdedor->goles_favor += $resultado->goles_equipo_1;
                $equipoPerdedor->goles_contra += $resultado->goles_equipo_2;
                $equipoPerdedor->partidos_jugados += 1;
                $equipoPerdedor->partidos_perdidos += 1;
                $equipoPerdedor->save();
            }else{
                $equipoEmpate1 = Equipo::find($resultado->equipo_1);
                $equipoEmpate1->goles_favor += $resultado->goles_equipo_1;
                $equipoEmpate1->goles_contra += $resultado->goles_equipo_2;
                $equipoEmpate1->partidos_jugados += 1;
                $equipoEmpate1->partidos_empatados += 1;
                $equipoEmpate1->puntos += 1;
                $equipoEmpate1->save();

                $equipoEmpate2 = Equipo::find($resultado->equipo_2);
                $equipoEmpate2->goles_favor += $resultado->goles_equipo_2;
                $equipoEmpate2->goles_contra += $resultado->goles_equipo_1;
                $equipoEmpate2->partidos_jugados += 1;
                $equipoEmpate2->partidos_empatados += 1;
                $equipoEmpate2->puntos += 1;
                $equipoEmpate2->save();
            }

            $partidoJugado = Partido::find($resultado->partido_id);
            $partidoJugado->estado = 1;
            $partidoJugado->save();
        }
    }
}
