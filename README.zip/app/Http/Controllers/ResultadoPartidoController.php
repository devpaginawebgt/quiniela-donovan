<?php

namespace App\Http\Controllers;

use DateTime;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Equipo;
use App\Models\Partido;
use App\Models\Preccion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class ResultadoPartidoController extends Controller
{

    public function verQuiniela($jornada = 1, $message = '0OK')
    {
        $consulta1 = "SELECT partidos.id as partido_id,partidos.jornada,partidos.estado,
        partidos.fecha_partido,equipo_partidos.equipo_1,equipo_partidos.equipo_2
        FROM partidos
        INNER JOIN equipo_partidos on partidos.id = equipo_partidos.partido_id
        WHERE (partidos.jornada=$jornada)";

        $partidosJornada = DB::select($consulta1);
        foreach ($partidosJornada as $partido) {
            $equipo_1 = Equipo::find($partido->equipo_1);
            $equipo_2 = Equipo::find($partido->equipo_2);

            $prediccions = DB::select("SELECT preccions.goles_equipo_1,preccions.goles_equipo_2 FROM preccions
                                WHERE partido_id=$partido->partido_id AND user_id=". Auth::user()->id);
            $partido->pdg_equipo_1 = $prediccions[0]->goles_equipo_1??0;
            $partido->pdg_equipo_2 = $prediccions[0]->goles_equipo_2??0;

            $partido->nombre_equipo_1 = $equipo_1->nombre;
            $partido->imagen_equipo_1 = $equipo_1->imagen;

            $partido->nombre_equipo_2 = $equipo_2->nombre;
            $partido->imagen_equipo_2 = $equipo_2->imagen;
            $partido->fecha_partido = Carbon::create($partido->fecha_partido)->locale('es')->isoFormat('dddd D \d\e MMMM \d\e\l Y,  h:mm:ss A');

            $prediccion = DB::select("SELECT preccions.id,preccions.goles_equipo_1 as p_equipo_1, preccions.goles_equipo_2 as p_equipo_2, preccions.partido_id,resultado_partidos.goles_equipo_1,resultado_partidos.goles_equipo_2
                FROM `preccions`
                INNER JOIN resultado_partidos on preccions.partido_id = resultado_partidos.partido_id
                WHERE user_id=" . Auth::user()->id . " AND preccions.partido_id=$partido->partido_id");

            $partido->goles_equipo_1 = $prediccion[0]->goles_equipo_1??'';
            $partido->goles_equipo_2 = $prediccion[0]->goles_equipo_2??'';

            if ($partido->estado != 0) {
                if ($prediccion[0]->p_equipo_1 == $prediccion[0]->goles_equipo_1 && $prediccion[0]->p_equipo_2 == $prediccion[0]->goles_equipo_2) {
                    $partido->puntos = 3;
                } elseif ($prediccion[0]->p_equipo_1 > $prediccion[0]->p_equipo_2 && $prediccion[0]->goles_equipo_1 > $prediccion[0]->goles_equipo_2) {
                    $partido->puntos = 2;
                } elseif ($prediccion[0]->p_equipo_2 > $prediccion[0]->p_equipo_1 && $prediccion[0]->goles_equipo_2 > $prediccion[0]->goles_equipo_1) {
                    $partido->puntos = 2;
                } elseif ($prediccion[0]->p_equipo_2 == $prediccion[0]->p_equipo_1 && $prediccion[0]->goles_equipo_2 == $prediccion[0]->goles_equipo_1) {
                    $partido->puntos = 1;
                } else {
                    $partido->puntos = 0;
                }
            }
        }

        $this->actualizarPuntosParticipantes(Auth::user()->id);
        return view('modulos.quiniela', ['partidosJornada' => $partidosJornada,'message'=>$message??'','jornada'=>$jornada]);
    }

    public function verTablaResultados(){
        $this->actualizarPuntosParticipantes(Auth::user()->id);
        return view('modulos.tabla-resultados');
    }

    public function verTablaPremios(){
        $premios = DB::select("SELECT * FROM `premios` WHERE pais_id=" . Auth::user()->pais_id);
        return view('modulos.tabla-premios',["premios" => $premios]);
    }

    public function guardarPredicciones(Request $request)
    {
        try {
            $count_error=0;
            $message = "";
            $fecha_actual = new DateTime('now');

            foreach ($request->partidos as $partido) {
                $fecha_db = DB::select("select fecha_partido FROM partidos WHERE id=" . $partido['partido_id']);
                $fecha_partido = new DateTime($fecha_db[0]->fecha_partido);
                $diff = $fecha_actual->diff($fecha_partido);
                $diferencia_minutos = (($diff->days * 1440 + $diff->h * 60) + $diff->i);

                if ( $diferencia_minutos < 15) {
                    $count_error++;
                } else {
                    DB::table('preccions')->where('status', "=", 0)
                        ->updateOrInsert(
                            [
                                'user_id' => $request->user_id,
                                'partido_id' => $partido['partido_id']
                            ],
                            [
                                'goles_equipo_1' => $partido['marcador_equipo_1'],
                                'goles_equipo_2' => $partido['marcador_equipo_2']
                            ]
                        );
                }
            }

            if($count_error == 0){
                $message = "1OK";
            }else{
                $message = "2OK";
            }
        } catch (\Throwable $th) {
            $message = $th;
        }

        return json_encode($message);
    }
    
    public function guardarPrediccionesForm(Request $request){

        try {
            $count_error = 0;
            $message = "";
            $fecha_actual = new DateTime('now');

            foreach ($request->partidos as $partido_id) {
                $fecha_db = DB::select("select fecha_partido,estado FROM partidos WHERE id=" . $partido_id);
                $fecha_partido = new DateTime($fecha_db[0]->fecha_partido);
                $diff = $fecha_actual->diff($fecha_partido);
                $diferencia_minutos = (($diff->days * 1440 + $diff->h * 60) + $diff->i);

                if ($diferencia_minutos < 15) {
                    $count_error++;
                } else {
                    DB::table('preccions')->updateOrInsert(
                            [
                                'user_id' => Auth::user()->id,
                                'partido_id' => $partido_id
                            ],
                            [
                                'goles_equipo_1' => $request['prediccion_equipo1_'.$partido_id],
                                'goles_equipo_2' => $request['prediccion_equipo2_'.$partido_id]
                            ]
                    );
                }
            }

            if ($count_error == 0) {
                $message = "1OK";
            } else {
                $message = "2OK";
            }
        } catch (\Throwable $th) {
            $message = $th;
        }

        return redirect("ver-quiniela2/$request->jornada/$message");
    }

    public function obtenerPrediccionesGuardadas(Request $request){
        $consulta = "SELECT goles_equipo_1,goles_equipo_2,partido_id,jornada,estado 
        FROM preccions 
        INNER JOIN partidos on preccions.partido_id = partidos.id 
        WHERE (partidos.jornada=$request->jornada) and (preccions.user_id=$request->user_id)";

        $prediccionesPartidos = DB::select($consulta);

        return $prediccionesPartidos;
    }

    public function testPerformance($user_id){

        return $user_id;
    }

    public function obtenerParticipantes($user_id){
        $pais = DB::select("SELECT pais_id FROM users WHERE id=$user_id");
        $participantes = DB::select("SELECT users.id,users.name,nombres,apellidos,puntos,estado
        FROM users 
        INNER JOIN codigos on codigo_id=codigos.id 
        where estado !=0 AND users.pais_id=" . $pais[0]->pais_id . " ORDER by puntos desc");
        
        return json_encode($participantes);
    }

    public function actualizarPuntosParticipantes($user_id){
        $predicciones_resultados = DB::select("SELECT preccions.id,preccions.goles_equipo_1 as p_equipo_1, preccions.goles_equipo_2 as p_equipo_2, preccions.partido_id,resultado_partidos.goles_equipo_1,resultado_partidos.goles_equipo_2
        FROM `preccions` 
        INNER JOIN resultado_partidos on preccions.partido_id = resultado_partidos.partido_id
        WHERE user_id=$user_id AND status=0");

        foreach ($predicciones_resultados as $prediccion) {
            $usuario = User::find($user_id);
            if($prediccion->p_equipo_1==$prediccion->goles_equipo_1 && $prediccion->p_equipo_2==$prediccion->goles_equipo_2){
                $usuario->puntos += 3;
            }elseif ($prediccion->p_equipo_1 > $prediccion->p_equipo_2 && $prediccion->goles_equipo_1 > $prediccion->goles_equipo_2) {
                $usuario->puntos += 2;
            }elseif ($prediccion->p_equipo_2 > $prediccion->p_equipo_1 && $prediccion->goles_equipo_2 > $prediccion->goles_equipo_1) {
                $usuario->puntos += 2;
            }elseif ($prediccion->p_equipo_2 == $prediccion->p_equipo_1 && $prediccion->goles_equipo_2 == $prediccion->goles_equipo_1) {
                $usuario->puntos += 1;
            }else{
                $usuario->puntos += 0;
            }
            $usuario->save();

            $prediccion_guardada = Preccion::find($prediccion->id);
            $prediccion_guardada->status = 1;
            $prediccion_guardada->save();
        }
    }

    
}
