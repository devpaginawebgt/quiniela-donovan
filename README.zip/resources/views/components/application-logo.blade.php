<img src="{{asset('images/qatar-logo.png')}}" alt="Logo" class="max-h-16 rounded-lg fill-current">
