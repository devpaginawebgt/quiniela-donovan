<div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-medpharma">

    <div class="w-full sm:max-w-md mt-28 md:mt-6 px-6 py-4 h-auto bg-gray-800 bg-opacity-50 shadow-md sm:rounded-lg overflow-y-scroll">
        {{ $slot }}
    </div>
</div>
