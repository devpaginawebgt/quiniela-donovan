<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-white leading-tight">
            <?php echo e(__('Quiniela Qatar 2022')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="max-w-screen-2xl my-6 mx-auto sm:px-6 lg:px-8" id="selecciones-container">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="px-6 pb-6 bg-white border-b border-gray-200 ">
                <h5 class="text-3xl text-center font-bold my-8">Selecciones clasificadas</h5>
                <div class="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-x-2 gap-y-6 transition-all">
                    <?php $__currentLoopData = $selecciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seleccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="max-w-sm bg-white transform ease-in duration-150 hover:scale-105">
                        <div class="flex">
                            <img class="rounded-lg mx-auto hover:cursor-pointer btn-bandera border-2 border-gray-100 w-56 h-32"
                                src="<?php echo e(asset('images/selecciones/' . $seleccion->imagen)); ?>" alt="<?php echo e($seleccion->nombre); ?>" id="<?php echo e(str_replace(' ', '', $seleccion->nombre)); ?>" onclick="slideToggle(this.id)"/>
                        </div>
                        <div class="p-2">
                            <h5 class="mb-2 text-center text-2xl font-bold tracking-tight text-gray-900"><?php echo e($seleccion->nombre); ?></h5>
                            <div class="container-<?php echo e(str_replace(' ', '', $seleccion->nombre)); ?> hidden rounded-lg shadow-lg p-3">
                                <p class="mb-3 font-normal text-gray-700 dark:text-gray-400 text-center"><?php echo e($seleccion->descripcion); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Bor\Downloads\quiniela22\resources\views/modulos/selecciones.blade.php ENDPATH**/ ?>