<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-white leading-tight">
            <?php echo e(__('Quiniela Qatar 2022')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="max-w-screen-2xl my-6 mx-auto sm:px-6 lg:px-8" id="selecciones-container">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="px-6 pb-6 bg-white border-b border-gray-200 ">
                <h5 class="text-3xl text-center font-bold my-8">Grupos conformados</h5>
                <div class="flex flex-col">
                    <div class="xl:w-1/6 w-1/2 mx-auto mb-4">
                        <label for="grupos" class="block mb-2 text-sm font-medium text-gray-900">Seleccione: </label>
                        <div class="flex items-center justify-center">
                            <select id="grupos"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-lg font-semibold text-center cursor-pointer rounded-lg focus:ring-red-800 focus:border-red-800 block w-1/2 p-2.5"
                                onchange="verEquiposGrupo(this)">
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="E">E</option>
                                <option value="F">F</option>
                                <option value="G">G</option>
                                <option value="H">H</option>
                            </select>
                            <svg class="animate-spin spinner-load" viewBox="0 0 24 24"></svg>
                        </div>
                    </div>
                    <div class="w-full lg:w-3/4 overflow-x-auto relative shadow-md sm:rounded-lg mx-auto">
                        <table class="xl:w-full text-sm text-left text-gray-500">
                            <thead class="text-xs text-gray-100 uppercase bg-rose-900">
                                <tr>
                                    <th scope="col" class="py-3 px-6">
                                        Equipo
                                    </th>
                                    <th scope="col" class="py-3 px-6">
                                        PJ
                                    </th>
                                    <th scope="col" class="py-3 px-6">
                                        PG
                                    </th>
                                    <th scope="col" class="py-3 px-6">
                                        PE
                                    </th>
                                    <th scope="col" class="py-3 px-6">
                                        PP
                                    </th>
                                    <th scope="col" class="py-3 px-6">
                                        GF
                                    </th>
                                    <th scope="col" class="py-3 px-6">
                                        GC
                                    </th>
                                    <th scope="col" class="py-3 px-6">
                                        Puntos
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="body-equipos-grupo">

                            </tbody>
                        </table>
                    </div>

                    <div class="shadow-md rounded-md mx-auto w-full lg:w-3/4 my-4">
                        <p class="p-4 border-b border-rose-600 text-xl">Jornada 1</p>
                        <ul id="partidos-jornada-1">

                        </ul>
                    </div>

                    <div class="shadow-md rounded-md mx-auto w-full lg:w-3/4 my-4">
                        <p class="p-4 border-b border-rose-600 text-xl">Jornada 2</p>
                        <ul id="partidos-jornada-2">

                        </ul>
                    </div>

                    <div class="shadow-md rounded-md mx-auto w-full lg:w-3/4 my-4">
                        <p class="p-4 border-b border-rose-600 text-xl">Jornada 3</p>
                        <ul id="partidos-jornada-3">

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\Bor\Downloads\quiniela22\resources\views/modulos/grupos.blade.php ENDPATH**/ ?>