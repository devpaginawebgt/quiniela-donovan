<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = [
            [
                'name'      =>  'danielebs',
                'nombres'   =>  'Daniel',
                'apellidos' =>  'Bor',
                'numero_documento'  =>  '2855325880000',
                'email'     =>  'danielbor@gmail.com',
                'telefono'  =>  '545913913',
                'password'  =>  Hash::make('12345678'),
                'codigo_id'  =>  1
            ]
        ];

        DB::table('users')->insert($users);
    }
}
