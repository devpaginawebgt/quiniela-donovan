<?php

use App\Models\Equipo;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EquipoController;
use App\Http\Controllers\PartidoController;
use App\Http\Controllers\ResultadoPartidoController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/****** RUTAS GET PARA OBTENER VISTAS DE MODULOS */
Route::get('/', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');


Route::get('/ver-selecciones', function () {
    $selecciones  = Equipo::all();
    return view('modulos.selecciones',['selecciones'=>$selecciones]);
})->middleware(['auth'])->name('ver-selecciones');

Route::get('/ver-grupos', [EquipoController::class, 'verModuloGrupos'] )->middleware(['auth'])->name('ver-grupos');

Route::get('/participantes', [PartidoController::class, 'verParticipantes'] )->middleware(['guest']);

Route::get('/ver-calendario', function () {
    return view('modulos.calendario');
})->middleware(['auth'])->name('ver-calendario');

Route::get('/ver-sedes', function () {
    return view('modulos.sedes');
})->middleware(['auth'])->name('ver-sedes');

Route::get('/ver-quiniela2/{jornada?}/{message?}', [ResultadoPartidoController::class, 'verQuiniela'])->middleware(['auth'])->name('ver-quiniela2');
Route::post('/guardar-predicciones-form', [ResultadoPartidoController::class, 'guardarPrediccionesForm'] )->middleware(['auth'])->name('guardar-predicciones-form');

Route::get('/ver-tabla-resultados', [ResultadoPartidoController::class, 'verTablaResultados'] )->middleware(['auth'])->name('ver-tabla-resultados');

Route::get('/ver-tabla-premios', [ResultadoPartidoController::class, 'verTablaPremios'] )->middleware(['auth'])->name('ver-tabla-premios');

Route::get('/route-cache', function() {
    $exitCode = Artisan::call('route:cache');
    return '<h1>Routes cached</h1>';
});
Route::get('/clear', function() {

    $exitCode = Artisan::call('route:cache');
    return '<h1>Routes cached</h1>';
 
 });

require __DIR__.'/auth.php';
